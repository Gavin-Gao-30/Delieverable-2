package com.example.deliverables;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;

public class AssignInfo extends AppCompatActivity {
    private Button btn_back, btn_confirm;
    private EditText et_descrption, et_days, et_time, et_capacity, et_assign_code, et_teacher_name;
    private DataBaseHelper db = new DataBaseHelper(AssignInfo.this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_info);

        btn_back = findViewById(R.id.btn_assign_info_back);
        btn_confirm = findViewById(R.id.btn_assign_info_confirm);
        et_descrption = findViewById(R.id.et_assign_info_description);
        et_days = findViewById(R.id.et_assign_info_days);
        et_time = findViewById(R.id.et_assign_info_time);
        et_capacity = findViewById(R.id.et_assign_info_capacity);
        et_assign_code = findViewById(R.id.et_assign_info_code);
        et_teacher_name = findViewById(R.id.et_assign_info_name);




        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInstr();
            }
        });

        btn_confirm.setOnClickListener(new View.OnClickListener() {
            String code = et_assign_code.getText().toString();
            String info = et_descrption.getText().toString();
            String days = et_days.getText().toString();
            String time = et_time.getText().toString();
            String capacity = et_capacity.getText().toString();
            int stuDapacity = Integer.parseInt(capacity);
            String teacherName = et_teacher_name.getText().toString();
            @Override
            public void onClick(View view) {
                if (et_assign_code.getText().toString().isEmpty() || et_descrption.getText().toString().isEmpty()||et_days.getText().toString().isEmpty()||et_time.getText().toString().isEmpty()||et_capacity.getText().toString().isEmpty()){
                    Toast.makeText(AssignInfo.this, "Please Enter All Fields", Toast.LENGTH_SHORT).show();
                }
                else if(Integer.parseInt(capacity)<=0){
                    Toast.makeText(AssignInfo.this, "Student Capacity can't be zero or negative!", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(db.searchCourse(code)){
                        db.updateCourseInfo(code,info, days, time, stuDapacity,teacherName);
                    }
                }
                openInstr();

            }
        });


    }

    public void openInstr() {
        Intent intent = new Intent(this, Instr.class);
        startActivity(intent);

    }
}