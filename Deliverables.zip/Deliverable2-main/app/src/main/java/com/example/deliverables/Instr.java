package com.example.deliverables;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class Instr extends AppCompatActivity {
    private Button btn_instr_sign_out, btn_assign, btn_unAssign, btn_viewAll;
    private ListView lv_Allcourse;
    private EditText et_courseCode, et_courseName;
    private DataBaseHelper dbHelper = new DataBaseHelper(Instr.this);
    private ArrayAdapter courseArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instr);
        btn_instr_sign_out = (Button) findViewById(R.id.btn_instr_sign_out);
        btn_assign = (Button) findViewById(R.id.btn_instr_assign);
        btn_unAssign = (Button) findViewById(R.id.btn_instr_unassign);
        btn_viewAll = (Button) findViewById(R.id.btn_instr_view_all);
        lv_Allcourse= findViewById(R.id.lv_instr_view_all_course);
        et_courseCode = findViewById(R.id.et_instr_course_code);
        et_courseName = findViewById(R.id.et_instr_course_name);

        ShowAllCourseOnList(dbHelper);

        btn_instr_sign_out.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity();
            }
        });

        btn_viewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowAllCourseOnList(dbHelper);
            }
        });

        btn_assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAssignInfo();
            }
        });
    }
    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void ShowAllCourseOnList(DataBaseHelper dbHelper) { //show the entire course list


        ArrayList<String> infoArray = dbHelper.allCourses();
        courseArrayAdapter = new ArrayAdapter<String>(Instr.this, android.R.layout.simple_list_item_1, infoArray);
        lv_Allcourse.setAdapter(courseArrayAdapter);
    }

    public void openAssignInfo(){
        Intent intent = new Intent(this, AssignInfo.class);
        startActivity(intent);
    }
}