package com.example.deliverables;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AssignInfo extends AppCompatActivity {
    private Button btn_back, btn_confirm;
    private EditText et_descrption, et_days, et_time, et_capacity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_info);

        btn_back = findViewById(R.id.btn_assign_info_back);
        btn_confirm = findViewById(R.id.btn_assign_info_confirm);
        et_descrption = findViewById(R.id.et_assign_info_description);
        et_days = findViewById(R.id.et_assign_info_days);
        et_time = findViewById(R.id.et_assign_info_time);
        et_capacity = findViewById(R.id.et_assign_info_capacity);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInstr();
            }
        });

        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_descrption.toString().isEmpty()||et_days.toString().isEmpty()||et_time.toString().isEmpty()||et_capacity.toString().isEmpty()){
                    Toast.makeText(AssignInfo.this, "Please Enter All Fields", Toast.LENGTH_SHORT).show();
                }
                openInstr();
            }
        });


    }

    public void openInstr() {
        Intent intent = new Intent(this, Instr.class);
        startActivity(intent);

    }
}