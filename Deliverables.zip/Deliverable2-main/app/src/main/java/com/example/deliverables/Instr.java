package com.example.deliverables;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Instr extends AppCompatActivity {
    private Button btn_instr_sign_out, btn_assign, btn_unAssign, btn_Edit, btn_search_byCode, btn_search_byName;
    private ListView lv_Allcourse, lv_searchCourse;
    private EditText et_courseCode, et_courseName;
    private DataBaseHelper dbHelper = new DataBaseHelper(Instr.this);
    private ArrayAdapter courseArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instr);
        btn_instr_sign_out = (Button) findViewById(R.id.btn_instr_sign_out);
        btn_assign = (Button) findViewById(R.id.btn_instr_assign);
        btn_unAssign = (Button) findViewById(R.id.btn_instr_unassign);
        btn_Edit = (Button) findViewById(R.id.btn_instr_edit);
        btn_search_byCode = findViewById(R.id.btn_instr_search_bycode);
        btn_search_byName = findViewById(R.id.btn_instr_search_byname);

        lv_Allcourse= findViewById(R.id.lv_instr_view_all_course);
        lv_searchCourse = findViewById(R.id.lv_instr_search_course);
        et_courseCode = findViewById(R.id.et_instr_course_code);
        et_courseName = findViewById(R.id.et_instr_course_name);



        ShowAllCourseOnList(dbHelper);

        btn_instr_sign_out.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity();
            }
        });

        btn_search_byCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String courseName = et_courseName.getText().toString();
                String courseCode = et_courseCode.getText().toString();
                if(dbHelper.searchCourse(courseCode)){
                    Toast.makeText(Instr.this, "CourseFound", Toast.LENGTH_SHORT).show();
                    ShowCourseByCode(dbHelper, courseCode);
                }
                else{
                    Toast.makeText(Instr.this, "Course Not Found!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_search_byName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String courseName = et_courseName.getText().toString();
                String courseCode = et_courseCode.getText().toString();
                if(dbHelper.searchCourseByName(courseName)){
                    ShowCourseByName(dbHelper, courseName);
                    Toast.makeText(Instr.this, "CourseFound", Toast.LENGTH_SHORT).show();
                }

                else{
                    Toast.makeText(Instr.this, "Course Not Found!", Toast.LENGTH_SHORT).show();
                }
            }
        });



        btn_assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String code = et_courseCode.getText().toString();

                if(code.isEmpty()){
                    Toast.makeText(Instr.this, "Please input a course code!", Toast.LENGTH_SHORT).show();
                }
                else if (dbHelper.searchCourse(code)){
                    String assignedTeacher = assignInstructorCheck(code);
                    if(assignedTeacher.equals("None")){
                        openAssignInfo();
                    }
                    else {
                        Toast.makeText(Instr.this, "Unable to Assign into a course due to existing Teacher, " + assignedTeacher, Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(Instr.this, "Course Not Found!", Toast.LENGTH_SHORT).show();
                }


            }
        });

        btn_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String code = et_courseCode.getText().toString();

            }
        });
    }
    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void ShowAllCourseOnList(DataBaseHelper dbHelper) { //show the entire course list


        ArrayList<String> infoArray = dbHelper.allCourses();
        courseArrayAdapter = new ArrayAdapter<String>(Instr.this, android.R.layout.simple_list_item_1, infoArray);
        lv_Allcourse.setAdapter(courseArrayAdapter);
    }

    public void openAssignInfo(){
        Intent intent = new Intent(this, AssignInfo.class);
        startActivity(intent);
    }

    private String assignInstructorCheck(String code) {
            String assignedTeacher = dbHelper.getAssignTeacher(code);
            return assignedTeacher;

    }



    private void ShowCourseByCode(DataBaseHelper dbHelper, String code) { //show the entire course list


        ArrayList<String> infoArray = dbHelper.searchedCoursesByCode(code);
        courseArrayAdapter = new ArrayAdapter<String>(Instr.this, android.R.layout.simple_list_item_1, infoArray);
        lv_searchCourse.setAdapter(courseArrayAdapter);
    }

    private void ShowCourseByName(DataBaseHelper dbHelper, String name) { //show the entire course list

        ArrayList<String> infoArray = dbHelper.searchedCoursesByName(name);
        courseArrayAdapter = new ArrayAdapter<String>(Instr.this, android.R.layout.simple_list_item_1, infoArray);
        lv_searchCourse.setAdapter(courseArrayAdapter);
    }
}